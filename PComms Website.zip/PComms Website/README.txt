Set Up Instruction
1. Go to connection.php
2. Change the sql password, which is behind "root"
3. Create a new database name pcomms
4. Open pcomms.sql and copy the codes and paste it into the newly made database
4. Done

If images are not showing
1. Go to image that are having issues
2. Change their src by adding or removing "."

For adding videos into the video tab
1. Go to video.php
2. Look for the Slideshow section
3. Download the video, links are provided
4. Put those video files into resources folder
5. Direct the source src ="", to those videos