<?php
include('server/connection.php');

session_start();

if(isset($_POST['login_btn'])){

    $email = $_POST['email'];
    $password = md5($_POST['password']);

    $stmt = $conn->prepare("SELECT ProfileID,Username,Email,FName,LName,Password,Gender,DateOfBirth,ContactNo,Address FROM PROFILE WHERE Email=? AND Password=? LIMIT 1");
    $stmt->bind_param('ss',$email,$password);

    if($stmt->execute()){
        $stmt->bind_result($profile_id,$username,$email,$fname,$lname,$password,$gender,$DOB,$contact_no,$address);
        $stmt->store_result();

        if($stmt->num_rows()==1){
            $stmt->fetch(); 

            $_SESSION['ProfileID'] = $profile_id;
            $_SESSION['Username'] = $username;
            $_SESSION['Email'] = $email;
            $_SESSION['FName'] = $fname;
            $_SESSION['LName'] = $lname;
            $_SESSION['Password'] = $password;
            $_SESSION['Gender'] = $gender;
            $_SESSION['DateOfBirth'] = $DOB;
            $_SESSION['ContactNo'] = $contact_no;
            $_SESSION['Address'] = $address;
            $_SESSION['logged_in'] = true;

            header('location:HomeWelcome.php?message=Logged in sucessfully');

        }else{
            header('location:Login.php?error=Invalid email or password');
        }

    }else{
        header('location:Login.php?error=Something went wrong');

    }
}

?>




<!DOCTYPE html>
<html>
    <head>
        <title>Login</title>
        
        <style>
            body{
                background-color: #e0e0e0;
            }

            * {
                box-sizing: border-box;
            }

            .column1{
                flex: 10%;
                width: 10%;
                padding: 10px;
                border: 3px solid;
                margin-top:100px;
                margin-left:200px;
                height: 500px;
                border-top-left-radius:30px;
                border-bottom-left-radius:30px;
                background-color: white;
            }

            .column2{
                flex: 40%;
                width: 10%;
                padding: 10px;
                border: 3px solid;
                margin-top:100px;
                margin-right:200px;
                border-left:none;
                border-top-right-radius:30px;
                border-bottom-right-radius:30px;
                background-color: white;
            }

            .row{
                display:flex;
            }

            .img1{
                margin:130px;
                margin-left:55px;
            }

            .login{
                font-family: monospace;
                font-size:35px;
            }

            .p1-mix{
                font-family: monospace;
                font-size:19px;
                margin-right:430px;
            }

            .p2-mix{
                font-family: monospace;
                font-size:19px;
                margin-right:440px;
            }

            .input1{
                font-family: monospace;
                border-radius:30px;
                border:2px solid;
                padding:15px;
                width:70%;
            }

            .input1:focus{
                background-color:#45657b;
                color:white;
            }

            .input1:focus::placeholder{
                background-color:#45657b;
                color:white;
            }

            .input1::placeholder{
                font-size: 14px;
            }

            .check{
                margin-left:-400px;
            }

            .btn1{
                font-family: monospace;
                background-color:white;
                border-radius: 20px;
                border:2px solid;
                padding:10px;
                padding-left: 15px;
                padding-right: 15px;
                margin-right:-460px;
                cursor:pointer;
            }

            .btn1:focus{
                background-color:#45657b;
                color:white;
            }

            .hide{
                display:none;
            }

            div.show:hover .hide{
                display:block;
            }

            div.show{
                font-family: monospace;
                margin-top:10px;
                font-size:15px;
            }

            .rmb{
                font-family: monospace;
                font-size:17px;
            }

            #upper{
                font-weight: bold;
            }

            a:hover, a:focus{
                color:red;
            }

            .bbtn{
                position: absolute;
                margin-left: 600px;
                
            }

            .btn{
                padding: 10px 30px;
                border-radius: 30px;
                font-family: monospace;
                border: 2px solid black;
                cursor: pointer;
                font-size: 15px;
                background-color: white;
                text-decoration: none;
                color: #740c03;
                margin-left: 20px;
            }

            p a:hover{
                background-color: #740c03;
                color: white;
                font-weight: bold;
                border-color: white;
            }
            
        </style>
    </head>

    <body>
        <center>
            <div class="row">
                <div class="column1">
                    <img src="../Resources/Web Application.png" width="200px" class="img1">
                </div>

                <div class="column2">
                    <br>

                    <p1 class="login">Login</p1> 
                    
                    <br><br><br><br>

                    <form method="POST" action="Login.php">
                    <?php if(isset($_GET['error'])){ ECHO '<script>alert("'.$_GET['error'].'");</script>';}?>
                    <p1 class="p2-mix" id="upper">Email :</p1> <br>
                    <input type="text" placeholder="Enter Email" name="email" class="input1">    

                    <br><br><br>

                    <p1 class="p1-mix" id="upper">Password:</p1> <br>
                    <input type="password" placeholder="Enter Password" name="password" class="input1">

                    <br><br>
                    <br><br><br>

                    <div class="bbtn">
                        <input type="submit" class="btn" name="login_btn" value="LOGIN"/>
                    </div>

                    <br><br>

                    <div class="show">
                        <p1><b>Don't have an account yet?</b></p1> <br><br>
                        <p1 class="hide"><b>Click <a href="UserRegister.php"><i>HERE</i></b></a></p1>
                    </div>
                    </form>

                </div>
            </div>
        </center>
    </body>
</html>