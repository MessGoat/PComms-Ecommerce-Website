<!DOCTYPE html>
<html>
    <head>
        <title>Baby Store</title>
    </head>

    <body>
        <style>
            *{
                margin: 0;
                padding: 0;
            }

            body{
                background-color: #e0e0e0;
                text-align: center;
            }

            .wrapper{
                width: 90%;
                margin: 0 auto;
            }

            header{
                width: 100%;
                height: 110px;
                background-color: #d54336;
                position: fixed;
                z-index: 1;
            }

            .logo{
                margin-top: 10px;
                float: left;
                width: 5%;
            }

            .img{
                width: 110%;
            }

            .nav1{
                margin-left: 20px;
                float: left;
                line-height: 100px;
            }

            .nav1 a{
                text-decoration: none;
                font-family: monospace;
                letter-spacing: 2px;
                font-size: 35px;
                color: #740c03;
                padding: 40px;
            }

            .ShoppingCart,.SplitScreen,.Profile{
                margin-top: 20px;  
            }

            nav a:hover{
                background-color: #740c03;
                color: white;
                font-weight:bold;
            }

            .dropdown a:link,.dropdown a:visited,.dropdown-content a:link,.dropdown-content a:visited{
                font-size: 16px;
                font-family: monospace;
                right: 10px;
                bottom: 30px;
                background-color: white;
                color: #740c03;
                border:2px solid white;
                border-radius:20px; 
                text-align: center;
                padding: 10px 20px; 
                display: inline-block; 
                text-decoration: none;
            }

            .dropdown a:hover,.dropdown-content a:hover{
                font-family: monospace;
                background-color: #740c03;
                color: white;
                font-weight: bold;
            }   

            .dropdown a:active,.dropdown-content a:active{
                background-color: white;
                color: #740c03;
            }

            .dropdown{
                position: relative;
                display: inline-block;
            }

            .dropdown-content{
                right: 35px;
                top: 15px;
                display: none;
                position: absolute;
                font-size: 16px;
            }

            .dropdown:hover .dropdown-content{
                display: block;
            }

            .profile{
                font-family: monospace;
                font-size: 16px;
                display:inline; 
            }

            .profile-content a:link,.profile-content a:visited{
                font-size: 16px;
                font-family: monospace;
                background-color: white;
                color: #740c03;
                border:2px solid white;
                border-radius:20px; 
                text-align: center;
                padding: 10px 20px; 
                text-decoration: none;
                display:block;
            }

            .profile-content a:hover{
                font-family: monospace;
                background-color: #740c03;
                color: white;
                font-weight: bold;
            }

            .profile-content a:active{
                background-color: white;
                color: #740c03;
            }

            .profile-content{
                right: 48px;
                position: absolute;
                font-size: 16px;
                display: none;
                top: 90px;
            }

            .profile-content a{
                margin: 3px;
            }

            .profile:hover .profile-content{
                display: block;
            }

            .imgContact{
                width: 40px;
                border: 3px solid white;
                border-radius: 50px;
                background-color: white;
            }

            .ContactUsWord a{
                font-family: monospace;
                font-weight: bold;
                text-decoration: none;
                font-size: 18px;
                line-height:45px;
                color: white;
                padding: 8px;
            }

            .ContactUsWord a:hover{
                color: #45657b;
            }

            .ContactUs{
                display: flex;
                position: fixed;
                margin-top: 600px;
                margin-left: 40px;
                border: 1px solid #00C9D8;
                border-radius: 50px;
                width: 170px;
                height: 45px;
                background-color: #00C9D8;
            }

            .ShopBanner{
                font-family: monospace;
                padding: 10px 20px;
                font-size: 25px;
                letter-spacing: 2px;
                text-align: left;
            }

            .myShop{
                display: flex;
                border-bottom: 3px solid black;
                width: 1000px;
                margin: auto;
                padding: 50px;
            }

            .Shopimg1{
                border: 3px solid black;
                border-radius: 25px;
                width: 260px;
                max-width: 260px;
                height: 220px;
            }

            .ShopDescription{
                letter-spacing: 0px;
            }

            .ShopName{
                font-size: 40px;
            }

            .Seller{
                font-size: 20px;
            }

            address{
                font-size: 15px;
                padding: 5px;
            }

            p a:hover{
                background-color: #740c03;
                color: white;
                font-weight: bold;
                border-color: white;
            }

            #top1{
                font-family: monospace;
                font-size: 30px;
                line-height: 55px;
                margin:auto;
                background-color: #45657b;
                width: 1100px;
                height: 50px;
                border-bottom: 5px solid #ffbd59;
            }

            .Product11{
                display: flex;
                width: 1000px;
                padding: 50px;
                margin-left: 200px;
                line-height: 30px;
            }

            .ProductBanner{
                font-family: monospace;
                padding: 10px 20px;
                font-size: 20px;
                letter-spacing: 2px;
                text-align: left;
            }

            .Productimg1{
                border: 3px solid black;
                border-radius: 25px;
                width: 220px;
                max-width: 220px;
                height: 220px;
            }

            .ProductDescription1{
                text-align: right;
            }

            h1 a:link,h1 a:visited{
                color: black;
                font-size: 30px;
            }

            h1 a:hover{
                color: #45657b;
            }

            h1 a:active{
                color: #ffbd59;
            }

        </style>

<header>
    <div class="wrapper">
        <div class="logo">
            <a href="Home.php"><img src="../Resources/Web Application.png" class="img"></a>
        </div>

        <nav class="nav1">
            <a href="Shop.php">Shop</a>
            <a href="Community.php">Community</a>
            <a href="Video.php">Video</a>
            <a href="AboutUs.php">About Us</a>
        </nav>
            <div class="dropdown"><a href="Home.php" class="dropdown">ENGLISH &#11167;</a>
                <div class="dropdown-content">
                    <a href="Home(bm).php">MALAY</a>
                </div>
            </div>

            <a href="ShoppingCart.php"><img src="../Resources/kisspng-computer-icons-shopping-cart-shopping-cart-decoration-5ae1d7b85ac7e8.6820508115247502643719.png" width="5%" height="5%" class="ShoppingCart"></a>
            &nbsp;
            <a href="SplitScreen.php"><img src="../Resources/split-screen.png" width="5%" height="5%" class="SplitScreen"></a>
            &nbsp;&nbsp;
            <div class="profile"><img src="../Resources/computer-icons-user-profile-circle-abstract-449b748c464eba566641217282fff3a1.png" width="5%" height="5%">
                <div class="profile-content">
                    <a href="Profile.php">VIEW PROFILE</a>
                </div>
            </div>
    </div>
</header>

<div class="ContactUs">
    <a href="ContactUs.php"><img src="../Resources/contact.png" class="imgContact"></a>
    <div class="ContactUsWord">
        <a href="ContactUs.php">CONTACT US</a>
    </div>
</div>

        <br><br><br><br><br><br><br>

        <div class="myShop">
            <img src="../Resources/baby.jpeg" class="Shopimg1">
            <div class="ShopBanner">
                <h1 class="ShopName">Baby Store</h1>
                <h3 class="Seller">Muhamad WAHAHA</h3> 
                <br><br>
                <address>52, 52A, Jalan Cerdas, Cheras, 56000, Kuala Lumpur</address>
            </div>
        </div>
        <br><br>
        <caption id="top">
            <div id="top1">
                <p><font style="color: white;">PRODUCTS</font></p>
            </div>
        </caption>

        <table>
        <?php include('server/get_babystore_product.php');?>
        <?php while($row=$babystore_product->fetch_assoc()){?>
        <tr>
            <td>
                <div class="Product11">
                <img src="../Resources/<?php ECHO $row['Image'];?>" class="Productimg1">
                    <div class="ProductBanner">
                        <h1 class="ProductDescription"><a href="<?php ECHO "Product.php?ProductID=".$row['ProductID'];?>"><?php ECHO $row['ProductName'];?></a></h1>
                        <br>
                        <br><br><br><br>
                        <p class="ProductDescription">RM<?php ECHO $row['Price'];?></p>
                    </div>
                </div>
            </td>
        </tr>
        <?php }?>
    </table>

    <br><br><br><br>
    </body>
</html>
