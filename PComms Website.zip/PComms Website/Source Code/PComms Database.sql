
DROP DATABASE pcomms;
CREATE DATABASE pcomms;
USE pcomms;

#Profile

CREATE TABLE PROFILE(
ProfileID INT(11) NOT NULL AUTO_INCREMENT,
FName VARCHAR(500),
LName VARCHAR(500),
Username VARCHAR(500),
Password VARCHAR(500),
Gender CHAR(1) CHECK(Gender IN('M','F')),
Image VARCHAR(500),
DateOfBirth VARCHAR(500),
ContactNo VARCHAR(500),
Email VARCHAR(500) NOT NULL,
Address VARCHAR(500),
PRIMARY KEY(ProfileID)
);

DESC PROFILE;

INSERT INTO PROFILE VALUES (1,'Tan','Yi Yan','Tan Yi Yan','12345678','F','kun.jpg','10/29/1990','012-0123456','tanyiyan@gmail.com','26, Jalan Manis 3, Taman Bukit Segar, 56100 Cheras, Wilayah Persekutuan Kuala Lumpur');
INSERT INTO PROFILE VALUES (2,'Muhamad','WAHAHA','Muhamad WAHAHA','22222222','M','Ikun_with_no_bg_vect.webp','11/02/1995','017-6543210','WAHAHA@gmail.com','52, 52A, Jalan Cerdas, Cheras, 56000, Kuala Lumpur');
INSERT INTO PROFILE VALUES (3,'Zian','Yap Niu','Ali','88888888','M','user.png','05/10/2000','012-2223344','Alikunkun@gmail.com','No. 29, Jalan Alam Jaya 17, Taman Alam Jaya, Batu 7 1/2, 
                    <br>Cheras, 43200, Cheras, Selangor, 43200');

#Shop

CREATE TABLE Shop(
ShopID CHAR(8) NOT NULL,
ShopName VARCHAR(500),
Address VARCHAR(500),
ShopImage VARCHAR(500),
ShopLink VARCHAR(500),
PRIMARY KEY (ShopID)
);

DESC Shop;

INSERT INTO SHOP VALUES ('S000AAAA','Accessories','26, Jalan Manis 3, Taman Bukit Segar, 56100 Cheras, Wilayah Persekutuan Kuala Lumpur','accessories.png','Accessories');
INSERT INTO SHOP VALUES ('S000AAAB','Baby Store','52, 52A, Jalan Cerdas, Cheras, 56000, Kuala Lumpur','baby.jpeg','BabyStore');
INSERT INTO SHOP VALUES ('S000AAAC','Cookware','No. 29, Jalan Alam Jaya 17, Taman Alam Jaya, Batu 7 1/2, <br> Cheras, 43200, Cheras, Selangor, 43200','cook.jpg','Cookware');

#Product

CREATE TABLE PRODUCT(
ProductID CHAR(8) NOT NULL,
ProductName VARCHAR(500),
Image VARCHAR(500),
Price DECIMAL(10,2),
Stock INT(100),
Description VARCHAR(500),
ProductLink VARCHAR(500),
ShopID CHAR(8) NOT NULL,
PRIMARY KEY(ProductID),
Foreign Key(ShopID) REFERENCES Shop (ShopID)
);

DESC PRODUCT;

INSERT INTO PRODUCT VALUES ('P000AAAA','Screen Protector','screen.jpeg',20.00,100,'Upgraded 7H scratch resistance. Fused with 7H surface coating for even better scratch.','ScreenProtector','S000AAAA');
INSERT INTO PRODUCT VALUES ('P000AAAB','Almarai Powder Milk','almarai.jpeg',50.00,100,'Almarai full cream milk powder is rich in calcium, protein, vitamin A, C, and D3. It is also rich in iron and zinc. It comes with nutrients for the growth of bones, teeth, and muscles.','Almarai','S000AAAB');
INSERT INTO PRODUCT VALUES ('P000AAAC','TESCOMA PRESTO Silicone spatulas','TESCOMA PRESTO Silicone spatulas.jpeg',19.90,100,'Excellent for use in cookware with non-stick coating; it will not damage the surface made of heat-resistant silicone (220°C) and resistant plastic.','TESCOMA','S000AAAC');
INSERT INTO PRODUCT VALUES ('P000AAAD','Claypot','claypot.jpeg',40.00,100,'High quality products leading manufacturer in ceramic casseroles and clay pots.<br>&nbsp;&nbsp;- Suitable for gas stove, hot plat, radiant cooker
            <br>&nbsp;&nbsp;- Extreme temperature resistance from -20°C to 400 °C','Claypot','S000AAAC');
INSERT INTO PRODUCT VALUES ('P000AAAE','IPhone 13 Silicone Case with MagSafe','phone casing.jpg',219.90,100,'Designed by Apple to complement iPhone 13, the Silicone Case with MagSafe is a delightful way to protect your iPhone.','Iphone','S000AAAA');
INSERT INTO PRODUCT VALUES ('P000AAAF','Pampers','diaper.webp',29.99,100,'NEW IMPROVED Pampers all round protection pants have ANTI RASH BLANKET* containing Lotion with Aloe Vera, to keep your baby skin protected from redness and rashes.','diaper','S000AAAB');

SELECT * FROM PRODUCT;

#Seller

CREATE TABLE Seller(
SellerID CHAR(8) NOT NULL,
ProfileID INT(11),
ShopID CHAR(8) NOT NULL,
PRIMARY KEY(SellerID),
Foreign Key(ProfileID) REFERENCES Profile (ProfileID),
Foreign Key(ShopID) REFERENCES Shop (ShopID)
);

DESC Seller;

INSERT INTO Seller VALUES ('E000AAAA',1,'S000AAAA');
INSERT INTO Seller VALUES ('E000AAAB',2,'S000AAAB');
INSERT INTO Seller VALUES ('E000AAAC',3,'S000AAAC');

SELECT * FROM Seller;

#User

CREATE TABLE User(
UserID CHAR(8) NOT NULL,
ProfileID INT(11),
PRIMARY KEY(UserID),
Foreign Key(ProfileID) REFERENCES Profile (ProfileID)
);

DESC User;

INSERT INTO User VALUES ('U000AAAA',1);
INSERT INTO User VALUES ('U000AAAB',2);
INSERT INTO User VALUES ('U000AAAC',3);

#Video

CREATE TABLE Video(
VideoID CHAR(8) NOT NULL,
VideoLink VARCHAR(500),
VideoSource VARCHAR(500),
Title VARCHAR(500),
Description VARCHAR(500),
SellerID CHAR(8) NOT NULL,
ShopID CHAR(8) NOT NULL,
ProductID CHAR(8) NOT NULL,
PRIMARY KEY (VideoID),
Foreign Key(SellerID) REFERENCES Seller (SellerID),
Foreign Key(ShopID) REFERENCES Shop (ShopID),
Foreign Key(ProductID) REFERENCES Product (ProductID)
);

DESC Video;

INSERT INTO Video VALUES ('V000AAAA','https://www.youtube.com/watch?v=JumeqCM-dRI','How to apply a screenprotector - Tutorial.mp4','How to apply a Screen Protector?','Step-by-step teach you how to apply a Screen Protector.','E000AAAA','S000AAAA','P000AAAA');
INSERT INTO Video VALUES ('V000AAAB','https://www.youtube.com/watch?v=QqCDKc6Q8AU&ab_channel=%D8%A7%D9%84%D9%85%D8%B1%D8%A7%D8%B9%D9%8AAlmarai','Almarai Powder Milk TV Commercial.mp4','Almarai Powder Milk TV Commercial.','Almarai Powder Milk the best choice to protect your Family.','E000AAAB','S000AAAB','P000AAAB');
INSERT INTO Video VALUES ('V000AAAC','https://www.youtube.com/watch?v=BpnW2ghqI1U&ab_channel=tescomavideoEN','Silicone spatulas TESCOMA PRESTO.mp4','Silicone spatulas -- TESCOMA PRESTO.','- Excellent for use in cookware with non-stick coating; it will not damage the surface.','E000AAAC','S000AAAC','P000AAAC');
INSERT INTO Video VALUES ('V000AAAD','https://www.youtube.com/watch?v=0OJsM3jAQQ4&ab_channel=SoupedUpRecipes','How to Use a Clay Pot.mp4','How to Use a Clay Pot?','I hope you like my new product and have fun cooking with it =)','E000AAAC','S000AAAC','P000AAAD');

#Discussion Topic

CREATE TABLE DiscussionTopic(
ForumID CHAR(8) NOT NULL,
Title VARCHAR(500),
Description VARCHAR(500),
DateUpload DATE,
SellerID CHAR(8) NOT NULL,
ShopID CHAR(8) NOT NULL,
ProductID CHAR(8) NOT NULL,
PRIMARY KEY(ForumID),
Foreign Key(SellerID) REFERENCES Seller (SellerID),
Foreign Key(ShopID) REFERENCES Shop (ShopID),
Foreign Key(ProductID) REFERENCES Product (ProductID)
);

DESC DiscussionTopic;

INSERT INTO DiscussionTopic VALUES('F000AAAA','How to apply a Screen Protector?','Step-by-step teach you how to apply a Screen Protector.',STR_TO_DATE('04/23/2024','%m/%d/%Y'),'E000AAAA','S000AAAA','P000AAAA');
INSERT INTO DiscussionTopic VALUES('F000AAAB','Why choose Almarai Powder Milk?','Almarai Powder Milk the best choice to protect your Family',STR_TO_DATE('03/14/2024','%m/%d/%Y'),'E000AAAB','S000AAAB','P000AAAB');

SELECT * FROM DiscussionTopic;

#Order

CREATE TABLE Orders(
order_id INT(11) NOT NULL AUTO_INCREMENT,
order_cost DECIMAL(10,2),
order_status VARCHAR(500) DEFAULT 'on_hold',
firstname VARCHAR(500),
lastname VARCHAR(500),
email VARCHAR(500),
contactNo VARCHAR(500),
address VARCHAR(500),
order_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
PRIMARY KEY(order_id)
);

DESC Orders;

#Orderitem

CREATE TABLE OrderItem(
item_id INT(11) NOT NULL AUTO_INCREMENT,
order_id INT(11)NOT NULL,
ProductID CHAR(8) NOT NULL,
Image VARCHAR(500),
ProductName VARCHAR(500),
product_price DECIMAL(10,2),
product_quantity INT,
order_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
PRIMARY KEY(item_id)
);

DESC OrderItem;

SELECT * FROM PROFILE;
SELECT * FROM Shop;
SELECT * FROM PRODUCT;
SELECT * FROM Seller;
SELECT * FROM User;
SELECT * FROM Video;
SELECT * FROM DiscussionTopic;
SELECT * FROM Orders;
SELECT * FROM OrderItem;
