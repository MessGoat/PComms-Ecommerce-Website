<?php

session_start();

if(!isset($_SESSION['logged_in'])){
    header('location:Login.php');
    exit;
}

if(isset($_GET['logout'])){
    if(isset($_SESSION['logged_in'])){
        unset($_SESSION['logged_in']);
        unset($_SESSION['ProfileID']);
        unset($_SESSION['Username']);
        unset($_SESSION['Email']);
        unset($_SESSION['FName']);
        unset($_SESSION['LName']);
        unset($_SESSION['Password']);
        unset($_SESSION['Gender']);
        unset($_SESSION['DateOfBirth']);
        unset($_SESSION['ContactNo']);
        unset($_SESSION['Address']);
        header('location:Login.php');
        exit;
    }
}

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Profile</title>

        <style>
            /*Banner*/
            *{
                margin: 0;
                padding: 0;
            }

            body{
                background-color: #e0e0e0;
                text-align: center;
            }

            .wrapper{
                width: 90%;
                margin: 0 auto;
            }

            header{
                width: 100%;
                height: 110px;
                background-color: #d54336;
                position: fixed;
                z-index: 1;
            }

            .logo{
                margin-top: 10px;
                float: left;
                width: 5%;
            }

            .img{
                width: 110%;
            }

            .nav1{
                margin-left: 20px;
                float: left;
                line-height: 100px;
            }

            .nav1 a{
                text-decoration: none;
                font-family: monospace;
                letter-spacing: 2px;
                font-size: 35px;
                color: #740c03;
                padding: 40px;
            }

            .ShoppingCart,.SplitScreen,.Profile{
                margin-top: 20px;  
            }

            nav a:hover{
                background-color: #740c03;
                color: white;
                font-weight:bold;
            }

            .dropdown a:link,.dropdown a:visited,.dropdown-content a:link,.dropdown-content a:visited{
                font-size: 16px;
                font-family: monospace;
                right: 10px;
                bottom: 30px;
                background-color: white;
                color: #740c03;
                border:2px solid white;
                border-radius:20px; 
                text-align: center;
                padding: 10px 20px; 
                display: inline-block; 
                text-decoration: none;
            }

            .dropdown a:hover,.dropdown-content a:hover{
                font-family: monospace;
                background-color: #740c03;
                color: white;
                font-weight: bold;
            }   

            .dropdown a:active,.dropdown-content a:active{
                background-color: white;
                color: #740c03;
            }

            .dropdown{
                position: relative;
                display: inline-block;
            }

            .dropdown-content{
                right: 35px;
                top: 15px;
                display: none;
                position: absolute;
                font-size: 16px;
            }

            .dropdown:hover .dropdown-content{
                display: block;
            }

            .profile{
                font-family: monospace;
                font-size: 16px;
                display:inline; 
            }

            .profile-content a:link,.profile-content a:visited{
                font-size: 16px;
                font-family: monospace;
                background-color: white;
                color: #740c03;
                border:2px solid white;
                border-radius:20px; 
                text-align: center;
                padding: 10px 20px; 
                text-decoration: none;
                display:block;
            }

            .profile-content a:hover{
                font-family: monospace;
                background-color: #740c03;
                color: white;
                font-weight: bold;
            }

            .profile-content a:active{
                background-color: white;
                color: #740c03;
            }

            .profile-content{
                right: 48px;
                position: absolute;
                font-size: 16px;
                display: none;
                top: 90px;
            }

            .profile-content a{
                margin: 3px;
            }

            .profile:hover .profile-content{
                display: block;
            }


            /*Content*/
            .row{
                display:flex;
            }

            .kun{
                border:2px solid;
                border-radius: 30px;
                width:470px;
                margin-top:100px;
                margin-left:100px;
            }

            .word{
                font-family: monospace;
                font-size:19px;
            }

            table{
                margin-top:100px;
                margin-left:100px;
            }

            button:focus{
                background-color:#45657b;
                color:white;
            }

            #upper{
                font-weight: bold;
            }

            /*Sticky*/
            .imgContact{
                width: 40px;
                border: 3px solid white;
                border-radius: 50px;
                background-color: white;
            }

            .ContactUsWord a{
                font-family: monospace;
                font-weight: bold;
                text-decoration: none;
                font-size: 18px;
                line-height:45px;
                color: white;
                padding: 8px;
            }

            .ContactUsWord a:hover{
                color: #45657b;
            }

            .ContactUs{
                display: flex;
                position: fixed;
                margin-top: 600px;
                margin-left: 40px;
                border: 1px solid #00C9D8;
                border-radius: 50px;
                width: 170px;
                height: 45px;
                background-color: #00C9D8;
            }

            .bbtn{
                margin-left: 1300px;                
            }

            .btn{
                padding: 10px 30px;
                border-radius: 30px;
                font-family: monospace;
                border: 2px solid black;
                cursor: pointer;
                font-size: 15px;
                background-color: white;
                text-decoration: none;
                color: #740c03;
                margin-left: 20px;
            }

            p a:hover{
                background-color: #740c03;
                color: white;
                font-weight: bold;
                border-color: white;
            }
        </style>
    </head>

    <body>
        <!--Banner-->
        <header>
    <div class="wrapper">
        <div class="logo">
            <a href="Home.php"><img src="../Resources/Web Application.png" class="img"></a>
        </div>

        <nav class="nav1">
            <a href="Shop.php">Shop</a>
            <a href="Community.php">Community</a>
            <a href="Video.php">Video</a>
            <a href="AboutUs.php">About Us</a>
        </nav>
            <div class="dropdown"><a href="Home.php" class="dropdown">ENGLISH &#11167;</a>
                <div class="dropdown-content">
                    <a href="Home(bm).php">MALAY</a>
                </div>
            </div>

            <a href="ShoppingCart.php"><img src="../Resources/kisspng-computer-icons-shopping-cart-shopping-cart-decoration-5ae1d7b85ac7e8.6820508115247502643719.png" width="5%" height="5%" class="ShoppingCart"></a>
            &nbsp;
            <a href="SplitScreen.php"><img src="../Resources/split-screen.png" width="5%" height="5%" class="SplitScreen"></a>
            &nbsp;&nbsp;
            <div class="profile"><img src="../Resources/computer-icons-user-profile-circle-abstract-449b748c464eba566641217282fff3a1.png" width="5%" height="5%">
                <div class="profile-content">
                    <a href="Profile.php">VIEW PROFILE</a>
                </div>
            </div>
    </div>
</header>

<div class="ContactUs">
    <a href="ContactUs.php"><img src="../Resources/contact.png" class="imgContact"></a>
    <div class="ContactUsWord">
        <a href="ContactUs.php">CONTACT US</a>
    </div>
</div>

        <br><br>

        <!--Content-->
        <center>
            <div class="row">
                <img src="../Resources/Web Application.png" class="kun">

                <table>
                    <tr>
                        <td class="word" id="upper">Username</td>
                        <td class="word">: &nbsp; <?php ECHO $_SESSION['Username'];?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <p1 id="upper">Profile ID</p1> : <?php ECHO $_SESSION['ProfileID'];?></td>
                    </tr>

                    <tr>
                        <td class="word" id="upper">First Name</td>
                        <td class="word">: &nbsp; <?php ECHO $_SESSION['FName'];?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <p1 id="upper">Last Name</p1> : <?php ECHO $_SESSION['LName'];?></td>
                    </tr>

                    <tr>
                        <td class="word" id="upper">Gender</td>
                        <td class="word">: &nbsp; <?php ECHO $_SESSION['Gender'];?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <p1 id="upper">Date of Birth</p1> : <?php ECHO $_SESSION['DateOfBirth'];?></td>
                    </tr>

                    <tr>
                        <td class="word" id="upper">Contact No</td>
                        <td class="word">: &nbsp; <?php ECHO $_SESSION['ContactNo'];?></td>
                    </tr>

                    <tr>
                        <td class="word" id="upper">Email</td>
                        <td class="word">: &nbsp; <?php ECHO $_SESSION['Email'];?></td>
                    </tr>

                    <tr>
                        <td class="word" id="upper">Address</td>
                        <td class="word">: &nbsp; <?php ECHO $_SESSION['Address'];?></td>
                    </tr>
                </table>
            </div>

            <div class="bbtn">
                <p><a href="profile.php?logout=1" class="btn" onclick="logout()">LOGOUT</a></p>
            </div>
        </center>

        <script type="text/javascript">

        function logout(){
            alert("Bye <?php ECHO $_SESSION['Username']?> T-T");
            alert("See you next Time....");
        }

        </script>
    </body>
</html>