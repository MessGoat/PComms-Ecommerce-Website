<?php

include('connection.php');

$stmt = $conn->prepare("SELECT * FROM PRODUCT LIMIT 4");

$stmt->execute();

$product = $stmt->get_result();

?>