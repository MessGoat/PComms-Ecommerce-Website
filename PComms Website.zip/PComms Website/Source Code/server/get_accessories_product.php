<?php

include('connection.php');

$stmt = $conn->prepare("SELECT * FROM PRODUCT WHERE shopID = 'S000AAAA'LIMIT 2");

$stmt->execute();

$accessories_product = $stmt->get_result();

?>