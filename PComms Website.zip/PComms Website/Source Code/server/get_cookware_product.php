<?php

include('connection.php');

$stmt = $conn->prepare("SELECT * FROM PRODUCT WHERE shopID = 'S000AAAC' LIMIT 2");

$stmt->execute();

$cookware_product = $stmt->get_result();

?>