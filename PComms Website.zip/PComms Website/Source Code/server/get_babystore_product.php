<?php

include('connection.php');

$stmt = $conn->prepare("SELECT * FROM PRODUCT WHERE shopID = 'S000AAAB' LIMIT 2");

$stmt->execute();

$babystore_product = $stmt->get_result();

?>